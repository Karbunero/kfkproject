@extends('layouts.backend') 
@section('content')

<div class="col-md-12">
    <div class="card card">
        <div class="card-header">
            <h3 class="card-title">
                {{ $title }}</h3>
            <div class="card-tools">
                <a href="/admin/berita" type="button">
                    <i class="fas fa-arrow-alt-circle-left" style="font-size:28px"></i>

                </a>
            </div>

            <!-- /.card-tools -->
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <form action="/admin/berita" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row">
                        <div class="col-sm-6">
        <!-- text input -->
        <div class="form-group">
            <label>Judul</label>
            <input
                name="judul"
                class="form-control @error('judul') is-invalid @enderror"
                type="text"
                value="{{ old('judul', $buku->judul ?? '') }}"
                placeholder="Judul">
            <div class="invalid-feedback">
                @error('judul')
                {{ $message }}
                @enderror
            </div>
        </div>
    </div>

    
        <!-- Foto input -->
        <div class="col-sm-6">
            <div class="form-group">
                <label for="foto">Foto</label>
                <input
                    type="file"
                    class="form-control-file @error('foto') is-invalid @enderror"
                    id="foto"
                    name="foto">
                @error('foto')
                <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
        </div>
                    <div class="col-sm-12">
                        <!-- textarea input -->
                        <div class="form-group">
                            <label>Isi Konten</label>
                            <textarea
                                name="isi_konten"
                                class="textarea @error('isi_konten') is-invalid @enderror"
                                placeholder="Isi Konten"
                                cols="50"
                                rows="5">{{ old('isi_konten', $konten->isi_konten ?? '') }}</textarea>

                            <div class="invalid-feedback">
                                @error('isi_konten')
                                {{ $message }}
                                @enderror
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-info">Simpan</button>
                <a href="/admin/berita" type="button" class="btn btn-danger float-right">Batal</a>
            </div>
        </form>
    </div>
    <!-- /.card-body -->
</div>
<!-- /.card -->
</div>

@endsection