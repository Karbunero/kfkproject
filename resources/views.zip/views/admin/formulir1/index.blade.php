@extends('layouts.backend')
@section('content')
    <div class="col-md-12">


        <div class="card card">


            <div class="card-header">
                <h3 class="card-title">{{ $title }}</h3>

                {{-- <div class="card-tools">
                    <a href="/admin/formulir1/create" type="button" class="btn btn-primary btn-sm btn-flat">
                        <i class="fa fa-plus"></i>
                        Add
                    </a>
                </div> --}}
                <!-- /.card-tools -->
            </div>

            <!-- /.card-header -->
            <div class="card-body">
                @if (session('pesan'))
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h5>
                            <i class="icon fas fa-check"></i>{{ session('pesan') }}
                        </h5>
                    </div>
                @endif
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th width="40px" class="text-center">No</th>
                            <th width="100px" class="text-center">Nama Lengkap</th>
                            <th width="100px" class="text-center">Gender</th>
                            <th width="100px" class="text-center">Asal Alamat Lengkap</th>
                            <th width="100px" class="text-center">No HP</th>
                            <th width="100px" class="text-center">Media Sosial</th>
                            <th width="100px" class="text-center">Judul Proyek Film</th>
                            <th width="100px" class="text-center">Logline</th>
                            <th width="100px" class="text-center">Sinopsis</th>
                            <th width="100px" class="text-center">Treatment</th>
                            <th width="100px" class="text-center">Statement Produser</th>
                            <th width="100px" class="text-center">Statement Sutradara</th>
                            <th width="100px" class="text-center">CV Filmography</th>
                            <th width="50px" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        @foreach ($formulir1 as $formulir1s)
                            <tr>
                                <td class="text-center">{{ $no++ }}</td>
                                <td class="text-center">{{ $formulir1s->nama_lengkap }}</td>
                                <td class="text-center">{{ $formulir1s->gender }}</td>
                                <td class="text-center">{{ $formulir1s->asal_alamat_lengkap }}</td>
                                <td class="text-center">{{ $formulir1s->no_hp }}</td>
                                <td class="text-center">{{ $formulir1s->media_sosial }}</td>
                                <td class="text-center">{{ $formulir1s->judul_proyek_film }}</td>
                                <td class="text-center">{{ $formulir1s->logline }}</td>
                                <td class="text-center">{{ $formulir1s->sinopsis }}</td>
                                <td class="text-center">
                                    @if ($formulir1s->treatment)
                                        <a href="{{ asset('foto/admin/pdf1/' . $formulir1s->treatment) }}"
                                            target="_blank">Lihat PDF</a>
                                    @else
                                        Tidak ada file
                                    @endif
                                </td>
                                <td class="text-center">{{ $formulir1s->statement_produser }}</td>
                                <td class="text-center">{{ $formulir1s->statement_sutradara }}</td>
                                <td class="text-center">
                                    @if ($formulir1s->cv_filmography)
                                        <a href="{{ asset('foto/admin/pdf2/' . $formulir1s->cv_filmography) }}"
                                            target="_blank">Lihat PDF</a>
                                    @else
                                        Tidak ada file
                                    @endif
                                </td>
                                <td class="text-center">
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                        data-target="#exampleModal{{ $formulir1s->id }}">
                                        <i class="fa fa-eye"></i> <!-- Gunakan ikon mata -->
                                    </button>


                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal{{ $formulir1s->id }}" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Detail Formulir</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <!-- Isi konten modal dengan detail formulir -->
                                                    <p><strong>Nama Lengkap:</strong> {{ $formulir1s->nama_lengkap }}</p>
                                                    <p><strong>Gender:</strong> {{ $formulir1s->gender }}</p>
                                                    <p><strong>Asal Alamat Lengkap:</strong>
                                                        {{ $formulir1s->asal_alamat_lengkap }}</p>
                                                    <p><strong>No HP:</strong> {{ $formulir1s->no_hp }}</p>
                                                    <p><strong>Media Sosial:</strong> {{ $formulir1s->media_sosial }}</p>
                                                    <p><strong>Judul Proyek Film:</strong>
                                                        {{ $formulir1s->judul_proyek_film }}</p>
                                                    <p><strong>Logline:</strong> {{ $formulir1s->logline }}</p>
                                                    <p><strong>Sinopsis:</strong> {{ $formulir1s->sinopsis }}</p>
                                                    <!-- Tambahkan detail lainnya sesuai kebutuhan -->
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">Tutup</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <form action="/admin/formulir1/{{ $formulir1s->id }}" method="post" class="d-inline">
                                        @method('delete')
                                        @csrf
                                        <button class="btn btn-danger btn-sm btn-flat"
                                            onclick="return confirm('Yakin Mau Hapus Data?')">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>


            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
@endsection
