@extends('layouts.backend') 
@section('content')

<div class="col-md-12">
    <div class="card card">
        <div class="card-header">
            <h3 class="card-title">
                {{ $title }}</h3>
            <div class="card-tools">
                <a href="/admin/artikel" type="button">
                    <i class="fas fa-arrow-alt-circle-left" style="font-size:28px"></i>

                </a>
            </div>

            <!-- /.card-tools -->
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <form action="/admin/artikel" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-sm-6">
                <!-- penulis -->
                <div class="form-group">
                    <label>Penulis</label>
                    <input
                        name="penulis"
                        class="form-control @error('penulis') is-invalid @enderror"
                        type="text"
                        value="{{ old('penulis', $artikel->penulis ?? '') }}"
                        placeholder="penulis">
                    <div class="invalid-feedback">
                        @error('penulis')
                        {{ $message }}
                        @enderror
                    </div>
                </div>
                <!-- judul -->
                <div class="form-group">
                    <label>Judul</label>
                    <input
                        name="judul"
                        class="form-control @error('judul') is-invalid @enderror"
                        type="text"
                        value="{{ old('judul', $artikel->judul ?? '') }}"
                        placeholder="Judul">
                    <div class="invalid-feedback">
                        @error('judul')
                        {{ $message }}
                        @enderror
                    </div>
                </div>
            </div>

    
        <div class="col-sm-6">
            <!-- Foto input -->
            <div class="form-group">
                <label for="foto">Foto</label>
                <input
                    type="file"
                    class="form-control-file @error('foto') is-invalid @enderror"
                    id="foto"
                    name="foto">
                @error('foto')
                <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <!-- tanggal -->
            <div class="form-group">
    <label>Tanggal</label>
    <input
        name="tanggal"
        class="form-control @error('tanggal') is-invalid @enderror"
        type="date"
        value="{{ old('tanggal', isset($artikel) ? optional($artikel->tanggal)->format('Y-m-d') : '') }}"
        placeholder="tanggal">
    <div class="invalid-feedback">
        @error('tanggal')
        {{ $message }}
        @enderror
    </div>
</div>

     </div>
                
                    <div class="col-sm-12">
                        <!-- textarea input -->
                        <div class="form-group">
                            <label>Kalimat</label>
                            <textarea
                                name="kalimat"
                                class="form-control @error('kalimat') is-invalid @enderror"
                                placeholder="kalimat">{{ old('kalimat', $artikel->kalimat ?? '') }}</textarea>
                            <div class="invalid-feedback">
                                @error('kalimat')
                                {{ $message }}
                                @enderror
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-info">Simpan</button>
                <a href="/admin/artikel" type="button" class="btn btn-danger float-right">Batal</a>
            </div>
        </form>
    </div>
    <!-- /.card-body -->
</div>
<!-- /.card -->
</div>

@endsection