@extends('layouts.backend') @section('content')

<div class="col-md-12">
    <div class="card card">
        <div class="card-header">
            <h3 class="card-title">
                {{ $title }}
            </h3>
            <div class="card-tools">
                <a href="/admin/artikel" type="button">
                    <i class="fas fa-arrow-alt-circle-left" style="font-size:28px"></i>

                </a>
            </div>

            <!-- /.card-tools -->
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <form action="/admin/artikel/{{ $artikel->id }}" method="POST" enctype="multipart/form-data">
                @method('put') @csrf
                <div class="row">
                    <div class="col-sm-6">
                        <!-- text input -->
                        <div class="form-group">
                            <label>Penulis </label>
                            <input name="penulis" class="form-control @error('penulis') is-invalid @enderror" type="text" value="{{ old('penulis', $artikel->penulis ?? '') }}" placeholder="Penulis">
                            <div class="invalid-feedback">
                                @error('penulis')
                                {{ $message }}
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <!-- text input -->
                        <div class="form-group">
                            <label>Foto</label>
                            <input name="foto" class="form-control @error('foto') is-invalid @enderror" type="file" value="{{ old('foto',$artikel->foto) }}" placeholder="foto">
                            <div class="invalid-feedback">
                                @error('foto')
                                {{ $message }}
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <!-- textarea input -->
                        <div class="form-group">
                            <label>Judul</label>
                            <textarea name="judul" class="textarea @error('judul') is-invalid @enderror" placeholder="Judul">{{ old('judul', $artikel->judul ?? '') }}</textarea>
                            <div class="invalid-feedback">
                                @error('judul')
                                {{ $message }}
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <!-- textarea input -->
                        <div class="form-group">
                            <label>Isi Konten</label>
                            <textarea name="kalimat" class="textarea @error('kalimat') is-invalid @enderror" placeholder="Isi Konten">{{ old('kalimat', $artikel->kalimat ?? '') }}</textarea>
                            <div class="invalid-feedback">
                                @error('kalimat')
                                {{ $message }}
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
    <!-- text input -->
    <div class="form-group">
        <label>Tanggal Kunjungan</label>
        <input name="tanggal" class="form-control @error('tanggal') is-invalid @enderror" type="date" value="{{ old('tanggal', $artikel->tanggal->format('Y-m-d')) }}" placeholder="Waktu Kunjungan">
        <div class="invalid-feedback">
            @error('tanggal')
            {{ $message }}
            @enderror
        </div>
    </div>
</div>


                </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-info">Simpan</button>
            <a href="/admin/artikel" type="button" class="btn btn-danger float-right">Batal</a>
        </div>
        </form>
    </div>
    <!-- /.card-body -->
</div>
<!-- /.card -->
</div>

@endsection