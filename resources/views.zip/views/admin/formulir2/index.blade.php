@extends('layouts.backend')
@section('content')
    <div class="col-md-12">


        <div class="card card">
            <div class="card-header">
                <h3 class="card-title">{{ $title }}</h3>

                <div class="card-tools">
                    <a href="/admin/formulir2/create" type="button" class="btn btn-primary btn-sm btn-flat">
                        <i class="fa fa-plus"></i>
                        Add
                    </a>
                </div>
                <!-- /.card-tools -->
            </div>

            <!-- /.card-header -->
            <div class="card-body">
                @if (session('pesan'))
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h5>
                            <i class="icon fas fa-check"></i>{{ session('pesan') }}
                        </h5>
                    </div>
                @endif
                <table id="example1" class="table table-bordered table-striped ">
                    <thead>
                        <tr>
                            <th width="40px" class="text-center">No</th>
                            <th width="100px" class="text-center">Judul Film</th>
                            <th width="100px" class="text-center">Nama Lengkap Sutradara</th>
                            <th width="100px" class="text-center">Kategori Film</th>
                            <th width="100px" class="text-center">Tahun Produksi</th>
                            <th width="100px" class="text-center">Komunitas Rumah Produksi</th>
                            <th width="100px" class="text-center">Logline</th>
                            <th width="100px" class="text-center">Sinopsis Pendek</th>
                            <th width="100px" class="text-center">Sinopsis Panjang</th>
                            <th width="100px" class="text-center">Kontak Whatsapp</th>
                            <th width="100px" class="text-center">Media Sosial Sutradara</th>
                            <th width="100px" class="text-center">Link</th>
                            <th width="50px" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        @foreach ($formulir2 as $formulir2s)
                            <tr>
                                <td class="text-center">{{ $no++ }}</td>
                                <td class="text-center">{{ $formulir2s->judul_film }}</td>
                                <td class="text-center">{{ $formulir2s->nama_lengkap_sutradara }}</td>
                                <td class="text-center">{{ $formulir2s->kategori_film }}</td>
                                <td class="text-center">{{ $formulir2s->tahun_produksi }}</td>
                                <td class="text-center">{{ $formulir2s->komunitas_rumah_produksi }}</td>
                                <td class="text-center">{{ $formulir2s->logline }}</td>
                                <td class="text-center">{{ $formulir2s->sinopsis_pendek }}</td>
                                <td class="text-center">{{ $formulir2s->sinopsis_panjang }}</td>
                                <td class="text-center">{{ $formulir2s->kontak_whatsapp }}</td>
                                <td class="text-center">{{ $formulir2s->media_sosial_sutradara }}</td>
                                <td class="text-center">{{ $formulir2s->link }}</td>
                                <td class="text-center">
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                        data-target="#exampleModal{{ $formulir2s->id }}">
                                        <i class="fa fa-eye"></i> <!-- Gunakan ikon mata -->
                                    </button>


                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal{{ $formulir2s->id }}" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Detail Formulir</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <!-- Isi konten modal dengan detail formulir -->
                                                    <p><strong>Judul Film:</strong> {{ $formulir2s->judul_film}}</p>
                                                    <p><strong>Nama Lengkap Sutradara:</strong> {{ $formulir2s->nama_lengkap_sutradara }}</p>
                                                    <p><strong>Kategori Film:</strong> {{ $formulir2s->kategori_film }}</p>
                                                    <p><strong>Tahun Produksi:</strong> {{ $formulir2s->tahun_produksi }}</p>
                                                    <p><strong>Komunitas Rumah Produksi:</strong> {{ $formulir2s->komunitas_rumah_produksi }}</p>
                                                    <p><strong>Logline:</strong> {{ $formulir2s->logline }}</p>
                                                    <p><strong>Sinopsis Pendek:</strong> {{ $formulir2s->sinopsis_pendek }}</p>
                                                    <p><strong>Sinopsis Panjang:</strong> {{ $formulir2s->sinopsis_panjang }}</p>
                                                    <p><strong>Kontak Whatsapp:</strong> {{ $formulir2s->kontak_whatsapp }}</p>
                                                    <p><strong>Media Sosial Sutradara:</strong> {{ $formulir2s->media_sosial_sutradara }}</p>
                                                    <p><strong>Link:</strong> {{ $formulir2s->link }}</p>
                                                    <!-- Tambahkan detail lainnya sesuai kebutuhan -->
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">Tutup</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <form action="/admin/formulir1/{{ $formulir2s->id }}" method="post" class="d-inline">
                                        @method('delete')
                                        @csrf
                                        <button class="btn btn-danger btn-sm btn-flat"
                                            onclick="return confirm('Yakin Mau Hapus Data?')">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>

                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
@endsection
