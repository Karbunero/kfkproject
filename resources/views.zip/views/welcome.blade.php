@extends('layouts.fontend')

@section('content')
    <h1 class="judul">ARTIKEL</h1>
    <div class="article-grid">
        @foreach ($artikels as $artikel)
        <div class="article">
            <a href="{{ route('user.show', $artikel->id) }}">
                <div class="article-content">
                    <div class="article-image">
                        <img src="{{ $artikel->foto ? asset('foto/artikel/' . $artikel->foto) : asset('foto/artikel/user.png') }}" alt="User Avatar" style="width: 100%; height: 150px; object-fit: contain;">
                        <!-- Contoh: Gambar memiliki ukuran tetap 200px lebar dan 150px tinggi -->
                    </div>
                </div>
            </a>
            <div class="article-text">
                <h2 class="article-title">
                    {{ Str::limit($artikel->judul, 100, '...') }}
                </h2>
                <div class="author">{{ $artikel->penulis }}</div>
                <hr> <!-- Garis pembatas -->
                <p class="article-sentence">
                    {{ Str::limit($artikel->kalimat, 100) }}
                    <a href="{{ route('user.show', $artikel->id) }}">Selengkapnya</a>
                </p>
                <p class="article-date">{{ $artikel->tanggal->format('d-m-Y') }}</p>
            </div>
        </div>
        @endforeach
    </div>
@endsection
