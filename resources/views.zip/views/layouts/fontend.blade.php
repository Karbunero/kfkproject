<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Tambahkan Font Awesome di bagian head -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="{{ asset('css/formulir1.css') }}" rel="stylesheet">
    <link href="{{ asset('css/user.css') }}" rel="stylesheet">
    <link href="{{ asset('css/welcome.css') }}" rel="stylesheet">

    <style>
        .navbar {
            background-image: url("{{ asset('foto') }}");
            background-size: cover;
            /* untuk mengisi seluruh area navbar dengan gambar */
            background-repeat: no-repeat;
            background-position: center;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }

        #sp-footer {
            background-color: rgb(0, 0, 0);
            /* Ubah latar belakang menjadi hitam */
            color: white;
            /* Ubah warna teks menjadi putih */
            padding: 20px 0;
            /* Berikan padding ke atas dan bawah untuk memberikan ruang */
        }

        .sp-column {
            text-align: center;
            /* Pusatkan teks di dalam kolom */
            margin-bottom: 10px;
            /* Berikan ruang di antara kolom */
        }

        .sp-whatsapp a {
            color: white;
            /* Ubah warna teks tautan menjadi putih */
        }

        .sp-whatsapp a:hover {
            color: gray;
            /* Ubah warna teks tautan saat digulir menjadi abu-abu */
        }
    </style>

    <title>{{ config('app.name', 'KMK') }}</title>
</head>

<body>



    @if (session('pinjam'))
    <script>
        Swal.fire({
            icon: 'success',
            title: '<span style="font-size: 24px;">Terima kasih!</span>',
            html: '<p style="font-size: 18px;"> {{ session('
            pinjam ') }}</p>',
            showConfirmButton: false,
            timer: 2000
        });
    </script>
    @endif @if (session('formulir1'))
    <script>
        Swal.fire({
            icon: 'success',
            title: '<span style="font-size: 24px;">Terima kasih!</span>',
            html: '<p style="font-size: 18px;"> {{ session('
            formulir1 ') }}</p>',
            showConfirmButton: false,
            timer: 2000
        });
    </script>
    @endif @if (session('formulir2'))
    <script>
        Swal.fire({
            icon: 'success',
            title: '<span style="font-size: 24px;">Terima kasih!</span>',
            html: '<p style="font-size: 18px;"> {{ session('
            formulir2 ') }}</p>',
            showConfirmButton: false,
            timer: 2000
        });
    </script>
    @endif @if (session('logout'))
    <script>
        Swal.fire({
            icon: 'success',
            title: '<span style="font-size: 24px;">Logout Berhasil</span>',
            showConfirmButton: false,
            timer: 2000
        });
    </script>
    @endif @if (session('hapus'))
    <script>
        Swal.fire({
            icon: 'success',
            title: '<span style="font-size: 24px;">Terima kasih!</span>',
            html: '<p style="font-size: 18px;"> {{ session('
            hapus ') }}</p>',
            showConfirmButton: false,
            timer: 2000
        });
    </script>
    @endif


<nav class="navbar sticky-top">
  <div class="navbar-left">
  <a href="{{ route('welcome') }}">Home</a>
  </div>
  <div class="navbar-center">
    <p class="navbar-title">FLOBAMORA FILM FESTIVAL</p>
  </div>
  <div class="navbar-right">
  <a href="/admin/login">Admin</a>
  </div>
</nav>

    <div id="carouselExample" class="carousel slide" data-ride="carousel" style="max-width: 1000px; margin: auto; position: relative;">
        <div class="carousel-indicators">
            <!-- <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExample" data-slide-to="1"></li>
        <li data-target="#carouselExample" data-slide-to="2"></li> -->
        </div>
        <div class="carousel-inner">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    @foreach (App\Models\Banner::all() as $ss => $banner)
                    <div class="carousel-item {{ $ss == 0 ? 'active' : '' }}" style="max-height: 400px;">
                        <img class="d-block w-100" src="{{ $banner->foto ? asset('foto/banner/' . $banner->foto) : asset('foto/banner/user.png') }}" alt="Banner {{ $ss + 1 }}">
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExample" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExample" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <hr>
    <div class="container  p-2 mb-2">
        <div class="formulir1">
            <a href="{{ url('/formulir1') }}">Formulir KFK Film Lab</a>
            <a href="{{ url('/formulir2') }}">Formulir Kompetisi</a>
        </div>

        @yield('content')

    </div>

    <style>
        /* Gaya CSS untuk link berwarna putih */
        #sp-footer a {
            color: white;
            text-decoration: none;
            /* Menghilangkan garis bawah pada link */
        }

        #sp-footer a:hover {
            text-decoration: underline;
            /* Efek garis bawah saat hover */
        }
    </style>

    <footer id="sp-footer">
        <div class="container">
            <div class="container-inner">
                <div class="row">
                    <div id="sp-footer3" class="col-md-3 col-lg-3">
                        <div class="sp-column">
                            <a href="https://web.facebook.com/komunitasfilm.kupang/?_rdc=1&_rdr" target="_blank">
                                <i class="fab fa-facebook-f"></i> KomunitasFilm Kupang
                            </a>
                        </div>
                    </div>

                    <div id="sp-footer3" class="col-md-3 col-lg-3">
                        <div class="sp-column">
                            <a href="https://www.tiktok.com/@komunitasfilmkupang" target="_blank">
                                <i class="fab fa-tiktok"></i> komunitasfilmkupang
                            </a>
                        </div>
                    </div>


                    <div id="sp-footer4" class="col-md-3 col-lg-3">
                        <div class="sp-column">
                            <a href="https://www.instagram.com/komunitasfilmkupang/" target="_blank">
                                <i class="fab fa-instagram"></i> komunitasfilmkupang
                            </a>
                        </div>
                    </div>
                    <div id="sp-footer3" class="col-md-3 col-lg-3">
                        <div class="sp-column">
                            <a href="https://www.tiktok.com/@flobamorafilmfestival" target="_blank">
                                <i class="fab fa-tiktok"></i> flobamorafilmfestival
                            </a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div id="sp-footer4" class="col-md-3 col-lg-3">
                        <div class="sp-column">
                            <a href="https://www.instagram.com/flobamorafilmfestival/" target="_blank">
                                <i class="fab fa-instagram"></i> flobamorafilmfestival
                            </a>
                        </div>
                    </div>
                    <div id="sp-footer3" class="col-md-3 col-lg-3">
                        <div class="sp-column">
                            <a href="https://www.facebook.com/events/kota-kupang/flobamora-film-festival/1731608530528226/?locale=ms_MY&_rdc=2&_rdr" target="_blank">
                                <i class="fab fa-facebook-f"></i> Flobamora Film Festival
                            </a>
                        </div>
                    </div>
                    <div id="sp-footer1" class="col-md-4 col-lg-4">
                        <div class="sp-column">
                            <a href="/admin/login" target="_blank">
                                <i class="fas fa-lock"></i> Login Admin
                            </a>
                        </div>
                    </div>


                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="sp-column text-center">
                            <span class="sp-copyright" id="copyright"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var currentYear = new Date().getFullYear();
            var copyrightElement = document.getElementById('copyright');
            copyrightElement.textContent = 'Copyright © ' + currentYear + ' ';
        });
    </script>

    <link href="{{ asset('css/buku.css') }}" rel="stylesheet">
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <script src="{{ asset('js/scripts.js') }}"></script>
</body>

</html>